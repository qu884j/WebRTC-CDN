# Client-side Maygh script

## Folder structure

* `app`: target JavaScript 
* `src`: source code
* `lib`: 3rd party library
* `out`: compiled target
* `www`: test & demo pages
* `tool`: utilities

## Compile

Once you have made your changes in the source JavaScript, you have to run `make.sh` in order to compile the final target script.