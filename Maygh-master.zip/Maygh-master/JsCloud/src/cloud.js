//#import flash.js
//#import util.base64.js
//#import browser.storage.js
//#import cloud.resource.js